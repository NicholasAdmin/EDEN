
    #include <stdio.h>
    int main()
    {
        printf("the quick brown fox jumps over the lazy god\n");
        return 0;
    }
    